﻿using ORM_DB_First.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAcces
{
    public class CompaniiAccessor
    {
        private DemoWebContext _context;

        public CompaniiAccessor()
        {
            _context = new DemoWebContext();
        }

        // Display all companies
        public List<Companii> GetAllCompanies()
        {
            try
            {
                return _context.Companiis.ToList();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error retrieving companies: {ex.Message}");
                return new List<Companii>();
            }
        }

        // Display company by ID
        public Companii GetCompanyById(int id)
        {
            try
            {
                return _context.Companiis.FirstOrDefault(c => c.IdCompanie == id);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error retrieving company with ID {id}: {ex.Message}");
                return null;
            }
        }

        // Insert new company
        public bool InsertCompany(string nume, string email, long? telefon, string adresa)
        {
            try
            {
                var newCompany = new Companii
                {
                    Nume = nume,
                    Email = email,
                    Telefon = telefon,
                    Adresa = adresa
                };

                _context.Companiis.Add(newCompany);
                int result = _context.SaveChanges();

                if (result > 0)
                {
                    Console.WriteLine($"Company '{nume}' inserted successfully with ID: {newCompany.IdCompanie}");
                    return true;
                }
                else
                {
                    Console.WriteLine("Failed to insert company.");
                    return false;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error inserting company: {ex.Message}");
                return false;
            }
        }

        // Update company
        public bool UpdateCompany(int id, string nume, string email, long? telefon, string adresa)
        {
            try
            {
                var company = _context.Companiis.FirstOrDefault(c => c.IdCompanie == id);
                if (company != null)
                {
                    company.Nume = nume;
                    company.Email = email;
                    company.Telefon = telefon;
                    company.Adresa = adresa;

                    int result = _context.SaveChanges();
                    if (result > 0)
                    {
                        Console.WriteLine($"Company with ID {id} updated successfully.");
                        return true;
                    }
                }
                else
                {
                    Console.WriteLine($"Company with ID {id} not found.");
                }
                return false;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error updating company: {ex.Message}");
                return false;
            }
        }

        // Delete company
        public bool DeleteCompany(int id)
        {
            try
            {
                var company = _context.Companiis.FirstOrDefault(c => c.IdCompanie == id);
                if (company != null)
                {
                    _context.Companiis.Remove(company);
                    int result = _context.SaveChanges();
                    if (result > 0)
                    {
                        Console.WriteLine($"Company with ID {id} deleted successfully.");
                        return true;
                    }
                }
                else
                {
                    Console.WriteLine($"Company with ID {id} not found.");
                }
                return false;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error deleting company: {ex.Message}");
                return false;
            }
        }

       
        // Dispose context
        public void Dispose()
        {
            _context?.Dispose();
        }
    }
}