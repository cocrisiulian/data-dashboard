﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace ORM_DB_First.Models;

public partial class DemoWebContext : DbContext
{
    public DemoWebContext()
    {
    }

    public DemoWebContext(DbContextOptions<DemoWebContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Companii> Companiis { get; set; }

    public virtual DbSet<Masini> Masinis { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Server=.\\SQLExpress;Database=DemoWeb;Trusted_Connection=True;persist security info=True;user id=sa;password=admin@PPAW;encrypt=True;trustservercertificate=True;");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Companii>(entity =>
        {
            entity.HasKey(e => e.IdCompanie);

            entity.ToTable("Companii");

            entity.Property(e => e.Adresa).HasMaxLength(200);
            entity.Property(e => e.Email).HasMaxLength(50);
            entity.Property(e => e.Nume).HasMaxLength(50);
        });

        modelBuilder.Entity<Masini>(entity =>
        {
            entity.HasKey(e => e.IdMasina);

            entity.ToTable("Masini");

            entity.Property(e => e.DataFabricatie).HasColumnType("datetime");
            entity.Property(e => e.Model).HasMaxLength(50);
            entity.Property(e => e.Pret).HasColumnType("decimal(18, 0)");

            entity.HasOne(d => d.IdCompanieNavigation).WithMany(p => p.Masinis)
                .HasForeignKey(d => d.IdCompanie)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Masini_Companii");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
