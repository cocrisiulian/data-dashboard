﻿using System;
using System.Collections.Generic;

namespace ORM_DB_First.Models;

public partial class Companii
{
    public int IdCompanie { get; set; }

    public string Nume { get; set; } = null!;

    public string? Email { get; set; }

    public long? Telefon { get; set; }

    public string? Adresa { get; set; }

    public virtual ICollection<Masini> Masinis { get; set; } = new List<Masini>();
}
