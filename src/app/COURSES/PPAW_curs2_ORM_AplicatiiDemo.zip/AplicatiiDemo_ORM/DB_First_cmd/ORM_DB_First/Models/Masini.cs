﻿using System;
using System.Collections.Generic;

namespace ORM_DB_First.Models;

public partial class Masini
{
    public int IdMasina { get; set; }

    public DateTime DataFabricatie { get; set; }

    public int IdCompanie { get; set; }

    public string Model { get; set; } = null!;

    public decimal Pret { get; set; }

    public virtual Companii IdCompanieNavigation { get; set; } = null!;
}
