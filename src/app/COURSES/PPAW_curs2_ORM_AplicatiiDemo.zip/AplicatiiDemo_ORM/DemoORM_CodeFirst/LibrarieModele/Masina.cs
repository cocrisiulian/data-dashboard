﻿
using System.ComponentModel.DataAnnotations;

namespace LibrarieModele
{
    public class Masina
    {
        [Key]
        public int IdMasina { get; set; }
        public System.DateTime DataFabricatie { get; set; }
        public int IdCompanie { get; set; }
        public string Model { get; set; }
        public decimal Pret { get; set; }

        public virtual Companie Companie { get; set; }
    }
}
