﻿using System;
using System.ComponentModel.DataAnnotations;

namespace LibrarieModele
{
    public class Companie
    {
        public Companie()
        {
           
        }
        [Key]
        public int IdCompanie { get; set; }
        public string Nume { get; set; }
        public string Email { get; set; }
        public Nullable<long> Telefon { get; set; }
        public string Adresa { get; set; }
    }

}
