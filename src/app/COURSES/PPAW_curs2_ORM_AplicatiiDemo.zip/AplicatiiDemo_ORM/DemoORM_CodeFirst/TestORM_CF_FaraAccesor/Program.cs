﻿using LibrarieModele;
using Repository_CodeFirst;
using System;
using System.Collections.Generic;
using System.Linq;

namespace TestORM_CF_FaraAccesor
{
    class Program
    {
        static void Main(string[] args)
        {
            DemoWebContext _context = new DemoWebContext();

            List<Companie> companii = _context.Companii.ToList();

            foreach (var company in companii)
            {
                Console.WriteLine($"ID: {company.IdCompanie}");
                Console.WriteLine($"Name: {company.Nume}");
                Console.WriteLine($"Email: {company.Email}");
                Console.WriteLine($"Phone: {company.Telefon}");
                Console.WriteLine($"Address: {company.Adresa}");
                Console.WriteLine("---");
            }
        }
    }
}
