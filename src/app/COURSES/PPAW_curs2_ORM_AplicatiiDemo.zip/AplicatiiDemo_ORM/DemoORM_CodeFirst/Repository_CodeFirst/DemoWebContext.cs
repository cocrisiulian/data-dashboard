﻿using LibrarieModele;
using System.Data.Entity;


namespace Repository_CodeFirst
{
    public class DemoWebContext : DbContext
    {
        public DemoWebContext()
            : base("name=DemoWebContext")
        {
        }

        public virtual DbSet<Companie> Companii { get; set; }
        public virtual DbSet<Masina> Masini { get; set; }
    }
}
