﻿namespace Repository_CodeFirst.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class initialDb_21oct2025 : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Companies",
                c => new
                    {
                        IdCompanie = c.Int(nullable: false, identity: true),
                        Nume = c.String(),
                        Email = c.String(),
                        Telefon = c.Long(),
                        Adresa = c.String(),
                    })
                .PrimaryKey(t => t.IdCompanie);
            
            CreateTable(
                "dbo.Masinas",
                c => new
                    {
                        IdMasina = c.Int(nullable: false, identity: true),
                        DataFabricatie = c.DateTime(nullable: false),
                        IdCompanie = c.Int(nullable: false),
                        Model = c.String(),
                        Pret = c.Decimal(nullable: false, precision: 18, scale: 2),
                    })
                .PrimaryKey(t => t.IdMasina)
                .ForeignKey("dbo.Companies", t => t.IdCompanie, cascadeDelete: true)
                .Index(t => t.IdCompanie);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Masinas", "IdCompanie", "dbo.Companies");
            DropIndex("dbo.Masinas", new[] { "IdCompanie" });
            DropTable("dbo.Masinas");
            DropTable("dbo.Companies");
        }
    }
}
