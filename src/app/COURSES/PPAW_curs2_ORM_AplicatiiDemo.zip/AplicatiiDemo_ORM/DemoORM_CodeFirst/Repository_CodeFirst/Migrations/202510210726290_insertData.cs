﻿namespace Repository_CodeFirst.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class insertData : DbMigration
    {
        public override void Up()
        {
            Sql("INSERT INTO Companies Values('Dacia','dacia@darex.ro', '12345','str. Victoriei');");
        }

        public override void Down()
        {
            Sql("DELETE FROM Companies Where CompanyName='Dacia';");
        }

    }
}
