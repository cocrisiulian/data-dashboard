﻿namespace Repository_CodeFirst.Migrations
{
    using LibrarieModele;
    using System;
    using System.Data.Entity;
    using System.Data.Entity.Migrations;
    using System.Linq;

    internal sealed class Configuration : DbMigrationsConfiguration<Repository_CodeFirst.DemoWebContext>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = false;
        }

        protected override void Seed(Repository_CodeFirst.DemoWebContext context)
        {
            //  This method will be called after migrating to the latest version.

            //  You can use the DbSet<T>.AddOrUpdate() helper extension method
            //  to avoid creating duplicate seed data.

            context.Companii.AddOrUpdate(
                c => c.Nume, // property used to check for duplicates
                new Companie { Nume = "Ford" },
                new Companie { Nume = "Tesla" },
                new Companie { Nume = "BMW" }
            );

            context.SaveChanges();
        }
    }
}
