﻿using DataAcces;
using System;

namespace TestORM_CF
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");
            Console.WriteLine("Welcome to the ORM Demo Project!");
            Console.WriteLine("================================\n");

            CompaniiAccessor companiiAccessor = new CompaniiAccessor();

            Console.WriteLine("\n--- Displaying All Companies ---");
            var companies = companiiAccessor.GetAllCompanies();

            foreach (var company in companies)
            {
                Console.WriteLine($"ID: {company.IdCompanie}");
                Console.WriteLine($"Name: {company.Nume}");
                Console.WriteLine($"Email: {company.Email}");
                Console.WriteLine($"Phone: {company.Telefon}");
                Console.WriteLine($"Address: {company.Adresa}");
                Console.WriteLine("---");
            }

        }
    }
}
