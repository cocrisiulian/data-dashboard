﻿using LibrarieModele;
using Repository_CodeFirst;
using System;
using System.Collections.Generic;
using System.Linq;

namespace DataAcces
{
    public class CompaniiAccessor
    {
        private DemoWebContext _context;

        public CompaniiAccessor()
        {
            _context = new DemoWebContext();
        }

        // Display all companies
        public List<Companie> GetAllCompanies()
        {
            try
            {
                return _context.Companii.ToList();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error retrieving companies: {ex.Message}");
                return new List<Companie>();
            }
        }

        // Display company by ID
        public Companie GetCompanyById(int id)
        {
            try
            {
                return _context.Companii.FirstOrDefault(c => c.IdCompanie == id);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error retrieving company with ID {id}: {ex.Message}");
                return null;
            }
        }

        // Insert new company
        public bool InsertCompany(string nume, string email, long? telefon, string adresa)
        {
            try
            {
                var newCompany = new Companie
                {
                    Nume = nume,
                    Email = email,
                    Telefon = telefon,
                    Adresa = adresa
                };

                _context.Companii.Add(newCompany);
                int result = _context.SaveChanges();

                if (result > 0)
                {
                    Console.WriteLine($"Company '{nume}' inserted successfully with ID: {newCompany.IdCompanie}");
                    return true;
                }
                else
                {
                    Console.WriteLine("Failed to insert company.");
                    return false;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error inserting company: {ex.Message}");
                return false;
            }
        }

        // Update company
        public bool UpdateCompany(int id, string nume, string email, long? telefon, string adresa)
        {
            try
            {
                var company = _context.Companii.FirstOrDefault(c => c.IdCompanie == id);
                if (company != null)
                {
                    company.Nume = nume;
                    company.Email = email;
                    company.Telefon = telefon;
                    company.Adresa = adresa;

                    int result = _context.SaveChanges();
                    if (result > 0)
                    {
                        Console.WriteLine($"Company with ID {id} updated successfully.");
                        return true;
                    }
                }
                else
                {
                    Console.WriteLine($"Company with ID {id} not found.");
                }
                return false;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error updating company: {ex.Message}");
                return false;
            }
        }

        // Delete company
        public bool DeleteCompany(int id)
        {
            try
            {
                var company = _context.Companii.FirstOrDefault(c => c.IdCompanie == id);
                if (company != null)
                {
                    _context.Companii.Remove(company);
                    int result = _context.SaveChanges();
                    if (result > 0)
                    {
                        Console.WriteLine($"Company with ID {id} deleted successfully.");
                        return true;
                    }
                }
                else
                {
                    Console.WriteLine($"Company with ID {id} not found.");
                }
                return false;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error deleting company: {ex.Message}");
                return false;
            }
        }


        // Dispose context
        public void Dispose()
        {
            _context?.Dispose();
        }
    }
}