﻿using DBFirst;
using System;


namespace ORM_DemoProject
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Welcome to the ORM Demo Project!");
            Console.WriteLine("================================\n");

            CompaniiAccessor companiiAccessor = new CompaniiAccessor();

            Console.WriteLine("\n--- Displaying All Companies ---");
            var companies = companiiAccessor.GetAllCompanies();

            foreach (var company in companies)
            {
                Console.WriteLine($"ID: {company.IdCompanie}");
                Console.WriteLine($"Name: {company.Nume}");
                Console.WriteLine($"Email: {company.Email}");
                Console.WriteLine($"Phone: {company.Telefon}");
                Console.WriteLine($"Address: {company.Adresa}");
                Console.WriteLine("---");
            }
        }
    }
}
